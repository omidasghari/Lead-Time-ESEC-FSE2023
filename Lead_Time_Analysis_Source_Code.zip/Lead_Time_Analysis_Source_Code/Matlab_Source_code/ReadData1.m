function [data] = ReadData(file, topic)
%file = The file destination with extention
%topic = The topic data you want as output (ulg = returns complete ulg file
%(all = returns all topics data)

ulog = ulogreader(file);

if strcmp(topic,'ulg')
    data = ulog;
elseif strcmp(topic,'all')
    data = readTopicMsgs(ulog);
else
    Topicdata = readTopicMsgs(ulog,'TopicNames',{topic}, ... 
        'InstanceID',{0});
    %data = timetable2table(Topicdata.TopicMessages{1,1});
    data = Topicdata.TopicMessages{1,1};
end

%loggedoutput = readLoggedOutput(ulog);

end