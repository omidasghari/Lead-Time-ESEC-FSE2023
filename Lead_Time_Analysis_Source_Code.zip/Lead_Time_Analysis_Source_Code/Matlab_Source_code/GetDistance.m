function Distance = GetDistance(PosData)
%Computes Distance tranvelled by the drone
%Distance = table;
xsss=PosData;
for i=1:length(PosData.lat)-1
    p1 = [PosData.lat(i),PosData.lon(i),PosData.alt(i)]
    p2 = [PosData.lat(i+1),PosData.lon(i+1),PosData.alt(i+1)]
    Distance(i) = pdist2(p1, p2);
    %Distance(i) = abs(distance(PosData.lat(i),PosData.lon(i),PosData.lat(i+1),PosData.lon(i+1)));
end
end

