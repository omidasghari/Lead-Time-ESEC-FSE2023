function [DataOutput] = LoadAllSheets(FileName)
%Load All Sheets Data
[sheets] = sheetnames(FileName);
num_sheets = length(sheets);
DataOutput=table;
for ii=1:num_sheets
    Name=sheets{ii};
    DataOutput.Drone{ii} = Name;
    DataOutput.Data{ii} = readtable(FileName,'Sheet',Name);
%     disp(DataOutput.Data{ii});
%     C = DataOutput.Data{ii}(2:end,:);
%     T = cell2table(C);
%     disp(T);
%     T = cell2table(DataOutput.Data{ii},...
%    "VariableNames",["Type" "BubbleAvoidanceCountEstGlobalPos" "Duration" "Distance" "Battery"]);

   %DataOutput1.Data{ii}=DataOutput.Data{ii}.Type; 
   %tnew = sortrows(DataOutput.Data{ii}.Type,ii)
end
end

