clc;
clearvars;

%addpath(genpath('FaultyRuns'));

logs = dir('FaultyRuns/*.ulg');
GoldObj = ReadData("GoldRun1.ulg", 'ulg');
GoldData.EstGlobalPos = GetTopicData(GoldObj, 'estimator_global_position',0);
GoldData.Duration = GoldObj.EndTime - GoldObj.StartTime;

FaultyData = table;

for i=1:length(logs)
    FaltyObj = ReadData(logs(i).name, 'ulg');
    FaultyData.EstGlobalPos{i} = GetTopicData(FaltyObj, 'estimator_global_position',0);
    FaultyData.Duration{i} = FaltyObj.EndTime - FaltyObj.StartTime;
end

clearvars logs i GoldObj FaltyObj;


%--------------------------------------


%https://www.mathworks.com/help/uav/ref/flightloganalyzer-app.html
%https://www.mathworks.com/help/uav/ref/ulogreader.html

%GoldObj = ReadData("GoldRun.ulg", 'ulg')
%FaultyObj = ReadData("FaultyRun64.ulg", 'ulg')

%GoldPosData = GetTopicData(GoldObj,'vehicle_gps_position',0)
%FaultyPosData = GetTopicData(FaultyObj,'vehicle_gps_position',0)

