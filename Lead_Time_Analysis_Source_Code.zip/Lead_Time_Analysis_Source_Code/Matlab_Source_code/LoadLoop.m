clc;
clearvars;

Glogs = dir('GoldRuns/*.ulg');

for i=1:length(Glogs)
    AnalyzeLog(strcat('GoldRuns/',Glogs(i).name),'zig-11-14.xlsx');
end

clearvars Glogs i;
