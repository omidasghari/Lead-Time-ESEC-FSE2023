Analysis = table;

%-------- Position

GoldPosData = GetTopicData(GoldObj,'vehicle_gps_position',0)
FaultyPosData = GetTopicData(FaultyObj,'vehicle_gps_position',0)

Analysis.Type = ["Gold";"Faulty64"]
Analysis.MaxDifLat = [max(diff(GoldPosData{:,2}));max(diff(FaultyPosData{:,2}))]
Analysis.MaxLat = [max(GoldPosData{:,2});max(FaultyPosData{:,2})]
Analysis.MinLat = [min(GoldPosData{:,2});min(FaultyPosData{:,2})]
Analysis.MeanLat = [mean(GoldPosData{:,2});mean(FaultyPosData{:,2})]

Analysis.MaxDifLon = [max(diff(GoldPosData{:,3}));max(diff(FaultyPosData{:,3}))]
Analysis.MaxLon = [max(GoldPosData{:,3});max(FaultyPosData{:,3})]
Analysis.MinLon = [min(GoldPosData{:,3});min(FaultyPosData{:,3})]
Analysis.MeanLon = [mean(GoldPosData{:,3});mean(FaultyPosData{:,3})]

Analysis.MaxDifAlt = [max(diff(GoldPosData{:,4}));max(diff(FaultyPosData{:,4}))]
Analysis.MaxAlt = [max(GoldPosData{:,4});max(FaultyPosData{:,4})]
Analysis.MinAlt = [min(GoldPosData{:,4});min(FaultyPosData{:,4})]
Analysis.MeanAlt = [mean(GoldPosData{:,4});mean(FaultyPosData{:,4})]


%-------- Acceleration


GoldAccelerationData = GetTopicData(GoldObj,'vehicle_acceleration',0)
FaultyAccelerationData = GetTopicData(FaultyObj,'vehicle_acceleration',0)
Analysis.MaxDifAcc = [max(diff(GoldAccelerationData{:,2}));max(diff(FaultyAccelerationData{:,2}))]
Analysis.MaxAcc = [max(GoldAccelerationData{:,2});max(FaultyAccelerationData{:,2})]
Analysis.MinAcc = [min(GoldAccelerationData{:,2});min(FaultyAccelerationData{:,2})]
Analysis.MeanAcc = [mean(GoldAccelerationData{:,2});mean(FaultyAccelerationData{:,2})]







