function AnalyzeLog(Name,FileName)
%Analyze the log data and save in the excelsheet
count=0;mindist= table;LeadTime=table;
DataAnalysis = table;
GoldObj = ReadData(Name, 'ulg');
GoldData.EstGlobalPos = GetTopicData(GoldObj, 'vehicle_gps_position_raw',0);
GoldData.Duration = GoldObj.EndTime - GoldObj.StartTime;
DataAnalysis.Type{1} = '-Gold';
DataAnalysis.BubbleThurshold{1} = max(GetDistance(GoldData.EstGlobalPos));% + 0.0002;
DataAnalysis.BubbleMinDistance{1} = min(GetDistance(GoldData.EstGlobalPos));
DataAnalysis.Distance{1} = 0;

DataAnalysis.Distance{1} = ComputeDistance(GoldData.EstGlobalPos)/1000;

logs = GetCurrentFolderList();
for j=1:length(logs)-1
    f1 = split(Name,'/');
    fname1 = char(f1(2));
    mission_name=split(fname1,'.');
    faultyfilename = string(logs(j).name)+'/'+fname1;
    FaltyObj = ReadData(faultyfilename, 'ulg');
    FaultyData.EstGlobalPos{j} = GetTopicData(FaltyObj, 'vehicle_gps_position_raw',0);
    FaultyData.Duration{j} = FaltyObj.EndTime - FaltyObj.StartTime;
end

for j=1:length(logs)-1
    name = split(logs(j).name,'.');
    DataAnalysis.Type{j+1} = name{1};
   

     t=GetMinDistanceFromTrajectory(FaultyData.EstGlobalPos{1,j},GoldData.EstGlobalPos,DataAnalysis.BubbleThurshold{1});

    if t~=-1000
            sj2 = string(FaltyObj.StartTime,'hh:mm:ss.SSS');
            dt2 = datetime( sj2, 'InputFormat', 'HH:mm:ss.SSS' ); 
            [Y, M, D, H, MN, S] = datevec(dt2);
            starttime=H*3600+MN*60+S;
            sj1 = string(t,'hh:mm:ss.SSS');
            dt = datetime( sj1, 'InputFormat', 'HH:mm:ss.SSS' ); 
            [Y, M, D, H, MN, S] = datevec(dt);
            times=H*3600+MN*60+S;
            leadTime=times-(starttime+50);
    end 
       
    LeadTime.InjectionDuration{j}=name;
          
             switch mission_name{1}
                 case "01"
                      if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end    
                 case "02" 
                    if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                    end  
                 case "03" 
                    if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                    end  
                 case "04"
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                     end  
                 case "05"  
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "06" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "07"   
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "08" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                     end
                 case "09" 
                    if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                    end  
                 case "10"
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                     end  
                 case "11" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                     end  
                 case "12" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "13"  
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "14" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                    end     
                         LeadTime.mission1{j}=0;
                 case "15" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "16" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                     end  
             
                 case "17"  
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "18" 
                    if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "19"  
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "20"   
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "21" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "22" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                     end  
                 case "23" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "24" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "25" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "26" 
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                      end 
                 case "27"   
                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                     end   
                 case "28"  

                     if t~=-1000
                          LeadTime.mission1{j}=leadTime;
                         
                      elseif t==-1000
                          LeadTime.mission1{j}=0;
                     end  
              
             end 
end 


f = split(fname1,'.');
durationsize = char(f(1));

writetable(LeadTime,FileName,'Sheet',durationsize)

clearvars logs i GoldObj Timestampe name Matrixdata Thurshold ThursholdGT finalRowData Bubble Duration  finalname f fn f1 fname1 fname;

end 

