function [data] = GetTopicData(object,topic,instance)
%Get topic from uld object

if strcmp(topic,'all')
    data = readTopicMsgs(object);
else
    Topicdata = readTopicMsgs(object,'TopicNames',{topic}, ... 
        'InstanceID',{instance});
    data = Topicdata.TopicMessages{1,1};
end

end
