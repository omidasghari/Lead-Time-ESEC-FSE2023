function Distance = ComputeDistanceRD(PosData)
T = timetable2table(PosData{1,1});
for i=1:length(T.lat)-1
    p1 = [T.lat(i),T.lon(i),T.alt(i)]
    p2 = [T.lat(i+1),T.lon(i+1),T.alt(i+1)]
    Distance(i) = pdist2(p1, p2);
    %Distance(i) = abs(distance(PosData.lat(i),PosData.lon(i),PosData.lat(i+1),PosData.lon(i+1)));
end
end
