function CreateNormalPlot(Xvalue,Yvalue, Name, Color)
%figure()
X = categorical(Xvalue)
Y = [Yvalue]
pp = bar(X,Y)
set(pp, {'DisplayName'}, {Name})
set(pp,'FaceColor',Color);
for i1=1:numel(Y)
    text(X(i1),Y(i1),num2str(Y(i1),'%0.1f'),...
               'HorizontalAlignment','center',...
               'VerticalAlignment','bottom')
end
legend()
title(Name)
end