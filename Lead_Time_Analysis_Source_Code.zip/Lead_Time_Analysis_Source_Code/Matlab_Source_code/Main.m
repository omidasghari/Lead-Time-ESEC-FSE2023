%Run Script LoadAllData before this if the data is not loaded
logs = dir('FaultyRuns/*.ulg');
BubbleAvoidanceData = table;
BubbleAvoidanceData.Type{1} = '-Gold';
BubbleAvoidanceData.BubbleAvoidanceCountEstGlobalPos{1} = 0;
BubbleAvoidanceData.Duration{1} = seconds(GoldData.Duration);
BubbleAvoidanceData.Distance{1} = 0;
Thurshold = 2;

BubbleAvoidanceData.Distance{1} = ComputeDistance(GoldData.EstGlobalPos);


for i=1:length(logs)
    FaultData.EstGlobalPos = FaultyData.EstGlobalPos{i};
    name = split(logs(i).name,'.');
    BubbleAvoidanceData.Type{i+1} = name{1};
    BubbleAvoidanceData.BubbleAvoidanceCountEstGlobalPos{i+1} = sum(diff(FaultData.EstGlobalPos{:,2})>max(diff(GoldData.EstGlobalPos{:,2}))*Thurshold) + sum(diff(FaultData.EstGlobalPos{:,3})>max(diff(GoldData.EstGlobalPos{:,3}))*Thurshold) + sum(diff(FaultData.EstGlobalPos{:,4})>max(diff(GoldData.EstGlobalPos{:,4}))*Thurshold);
    BubbleAvoidanceData.Duration{i+1} = seconds(FaultyData.Duration{i});
    BubbleAvoidanceData.Distance{i+1} = 0;
    BubbleAvoidanceData.Distance{i+1} = ComputeDistance(FaultData.EstGlobalPos);
end

writetable(BubbleAvoidanceData,'BubbleAvoidanceData.xlsx','Sheet',1)

CreateNormalPlot(BubbleAvoidanceData{:,1},BubbleAvoidanceData{:,2},'Bubble Avoidance','#3E4FC0')
CreateNormalPlot(BubbleAvoidanceData{:,1},BubbleAvoidanceData{:,3},'Duration (seconds)','#E5AE54')
CreateNormalPlot(BubbleAvoidanceData{:,1},BubbleAvoidanceData{:,4},'Distance (meters)','#881853')

clearvars logs i name FaultData Thurshold ThursholdGT Bubble Duration;