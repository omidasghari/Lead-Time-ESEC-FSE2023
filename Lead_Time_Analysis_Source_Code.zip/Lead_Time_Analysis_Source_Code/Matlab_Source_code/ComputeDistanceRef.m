function Distance = ComputeDistanceRef(PosData)
%Computes Distance tranvelled by the drone
Distance = 0;
for i=1:length(PosData.ref_lat)-1
    d = abs(distance(PosData.ref_lat(i),PosData.ref_lon(i),PosData.ref_lat(i+1),PosData.ref_lon(i+1)));
    Distance = Distance+d;
end
Distance = Distance * 100;
end

