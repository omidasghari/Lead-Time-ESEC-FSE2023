unction Timest = GetMinDistanceFromTrajectory(RowTr1,RefTrj,Thurshold)

ix=0;
Distances1=NaN(length(RowTr1.lat),1);

for i=1:length(RowTr1.lat)-1
    p1 = [RowTr1.lat(i),RowTr1.lon(i),RowTr1.alt(i)];
    Distancesj = NaN(1,length(RefTrj.lat));
      if ix==0
          for j=1:length(RefTrj.lat)
            p2 = [RefTrj.lat(j),RefTrj.lon(j),RefTrj.alt(j)];
            Distancesj(j) = pdist2(p1, p2);
               
          end
          
    elseif (ix>0 && ix<=100)
    
        for m=1:100+ix
            p2 = [RefTrj.lat(m),RefTrj.lon(m),RefTrj.alt(m)];
            Distancesj(m) = pdist2(p1, p2);
           
           
        end
     end    
    if (ix>100 && ix<length(RefTrj.lat)-100)
      
        for k=ix-100:ix+100
            p2 = [RefTrj.lat(k),RefTrj.lon(k),RefTrj.alt(k)];
            Distancesj(k) = pdist2(p1, p2);
          
     
        end  
    elseif  ix>=length(RefTrj.lat)-100    
     
        p1 = [RowTr1.lat(i),RowTr1.lon(i),RowTr1.alt(i)];
        for b=ix-100:length(RefTrj.lat)
            p2 = [RefTrj.lat(b),RefTrj.lon(b),RefTrj.alt(b)];
            Distancesj(b) = pdist2(p1, p2);
            
        end 
    end
     Distances1(i) = min(Distancesj);
     [~,ix] = min(Distancesj);
     if min(Distancesj) > Thurshold
        Timest=RowTr1.timestamp(i);
        break;
     end
     Timest=-1000;
end

end




