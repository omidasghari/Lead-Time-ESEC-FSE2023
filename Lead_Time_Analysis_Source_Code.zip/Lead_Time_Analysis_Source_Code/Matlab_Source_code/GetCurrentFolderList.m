function [ListOfFolders] = GetCurrentFolderList()
%Returns the list of Folders in current folder
d = dir;
d = d([d.isdir]);
ListOfFolders = d(~ismember({d(:).name},{'.','..','goldRuns'}));

end

