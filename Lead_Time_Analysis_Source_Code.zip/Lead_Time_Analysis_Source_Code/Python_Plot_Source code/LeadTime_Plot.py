from openpyxl import load_workbook
import statistics
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
from matplotlib.figure import Figure
import os
import glob
def main():
    path = os.getcwd()
    csv_files = glob.glob(os.path.join(path, "*.xlsx"))
    i=1
    for file in csv_files:
        fn = Path('/home/naghmeh/Desktop/output.svg').expanduser()
        book = load_workbook(file)
        sh=book.active
        sheet_number = len(book.worksheets)
        value = range(sheet_number)
        duration2 = []
        duration3 = []
        duration4 = []
        duration05 = []
        duration10 = []
        duration15 = []
        duration20 = []
        duration25 = []
        duration30 = []
        faultName=file.split('/')
        FaultName=str(faultName[len(faultName)-1]).split('.')
        FaultName=FaultName[0]

        for ws in book.worksheets:


                duration2.append(ws.cell(row=2, column=2).value)
                duration05.append(ws.cell(row=3, column=2).value)
                duration10.append(ws.cell(row=4, column=2).value)
                duration15.append(ws.cell(row=5, column=2).value)
                duration20.append(ws.cell(row=6, column=2).value)
                duration25.append(ws.cell(row=7, column=2).value)
                duration30.append(ws.cell(row=8, column=2).value)

             #print(ws.cell(row=j,column=2).value)
        if duration2.count(0) >= 15:
            duration2.clear()
        elif duration2.count(0) < 15:
            duration2 = [
                item for item in duration2
                if item != 0
            ]
        if duration05.count(0) >= 15:
                duration05.clear()
        elif duration05.count(0) < 15:
                duration05 = [
                    item for item in duration05
                    if item != 0
                ]
        if duration10.count(0) >= 15:
                duration10.clear()
        elif duration10.count(0) < 15:
                duration10 = [
                    item for item in duration10
                    if item != 0
                ]

        if duration15.count(0) >= 15:
            duration15.clear()
        elif duration15.count(0) < 15:
            duration15 = [
                item for item in duration15
                if item != 0
            ]
        if duration20.count(0) >= 15:
            duration20.clear()
        elif duration20.count(0) < 15:
            duration20 = [
                item for item in duration20
                if item != 0
            ]
        if duration25.count(0) >= 15:
            duration25.clear()
        elif duration25.count(0) < 15:
            duration25 = [
                item for item in duration25
                if item != 0
            ]
        if duration30.count(0) >= 15:
            duration30.clear()
        elif duration30.count(0) < 15:
            duration30 = [
                item for item in duration30
                if item != 0
            ]


            data = [duration2,duration05, duration10, duration15, duration20, duration25, duration30]
        plt.rcParams["figure.figsize"] = [4,4]
        plt.rcParams["figure.autolayout"] = True
        plt.subplot(1, 1, i)
        plt.ylim(0, 20)
        plt.locator_params(nbins=30)
        plt.boxplot(data, patch_artist=True, medianprops=dict(color='red'), capprops=dict(color='red'), flierprops=dict(color='red'))
        plt.xticks([1, 2, 3, 4, 5, 6, 7,],['02', '05','10', '15', '20', '25', '30'])
        print(data)
        plt.xlabel("Injection Duration (Sec)")
        plt.ylabel("Lead Time (Sec)")
        plt.grid(color='gray', linestyle='-', linewidth=0.6)
        plt.title(FaultName)
    #plt.figure(figsize=(10, 20))
        plt.savefig(fn, bbox_inches='tight')
        i = i + 1
    plt.tight_layout()
    plt.show()
#cell = currensheet['A1']
    #print(cell.value)
   # for currenrows in currensheet.rows:
      #  for currentcell in currenrows:
           # print(currentcell.number_format+":"+str(currentcell.value))
# Creating dataset
# Creating plot
if __name__ == "__main__":
    main()